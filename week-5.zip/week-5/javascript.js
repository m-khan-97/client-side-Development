var a=10;
function showMessage(){
    alert("Hello, This is JavaScript");
    
}