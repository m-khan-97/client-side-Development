var X = 10;
var Y = 5;
var Z = X + Y;
console.log("Task 1: X + Y =", Z); 

// Task 2: Use assignment operator to make Z = 15
Z = X + Y; // Already 15
console.log("Task 2: Z =", Z); // Output: 15

// Task 3: Use assignment operator to make Z = 50
Z = X * Y; // 10 * 5 = 50
console.log("Task 3: Z =", Z); // Output: 50

// Task 4: Show remainder of X = 15 / 9
var remainder = 15 % 9;
console.log("Task 4: Remainder of 15 / 9 =", remainder); // Output: 6


