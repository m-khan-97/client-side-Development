var X = 10;
var Y = 5;
var Z = X + Y;
console.log("Task 1 Result = ", Z);