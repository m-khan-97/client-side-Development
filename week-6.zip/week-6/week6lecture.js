// ---------------------- Task 5: Sum Until User Stops ----------------------
let sum = 0;
while (true) {
    let value = +prompt("Enter a number", '');
    if (!value) break;
    sum += value;
}
alert('Sum: ' + sum);



// ---------------------- Task 7: If Else Using Switch ----------------------
let inputNumber = +prompt("Enter a number:");
switch (true) {
    case (inputNumber > 0):
        alert("1");
        break;
    case (inputNumber < 0):
        alert("-1");
        break;
    default:
        alert("0");
}

// ---------------------- Task 8: While Loop Example ----------------------
let counter = 1;
while (counter <= 5) {
    console.log("Counter:", counter);
    counter++;
}

// ---------------------- Task 9: For Loop Example ----------------------
for (let i = 1; i <= 5; i++) {
    console.log("For Loop:", i);
}

// ---------------------- Task 10: Do-While Loop Example ----------------------
let doCounter = 5;
do {
    console.log("Do-While:", doCounter);
    doCounter--;
} while (doCounter > 0);

// ---------------------- Task 11: Break and Continue ----------------------
for (let i = 1; i <= 5; i++) {
    if (i === 3) break;
    console.log("Break Example:", i);
}

for (let i = 1; i <= 5; i++) {
    if (i === 3) continue;
    console.log("Continue Example:", i);
}
