// ---------------------- Task 2: Array Manipulation ----------------------
// let styles = ["Jazz", "Blues"];
// console.log(styles);

// styles.push("Rock-n-Roll");
// console.log(styles);

// styles[1] = "Classics"; // Replacing middle element
// console.log(styles);

// console.log(styles.shift()); // Remove first element
// console.log(styles);

// styles.unshift("Rap", "Reggae");
// console.log(styles);



// // ---------------------- Task 3: Official Name of JavaScript ----------------------
let jsName = prompt('What is the "official" name of JavaScript?');

if (jsName === "ECMAScript") {
    alert("Right!");
} else {
    alert("Didn’t know? ECMAScript!");
}










// // ---------------------- Task 4: Check Number ----------------------
// let number = prompt("Enter a number:");
// if (number > 0) {
//     alert("1");
// } else if (number < 0) {
//     alert("-1");
// } else {
//     alert("0");
// }


// // ---------------------- Advance Task 1: Ternary Operator (a + b < 4) ----------------------
// let a = 2, b = 1;
// let result = (a + b < 4) ? 'Below' : 'Over';
// console.log("Result of a + b check:", result);




// // ---------------------- Advance Task 2: Multiple Ternary Operators ----------------------
// let login = prompt("Enter your role (Employee, Director, or leave empty):");

// let message = (login == 'Employee') ? 'Hello' :
//               (login == 'Director') ? 'Greetings' :
//               (login == '') ? 'No login' :
//               '';
// console.log("Login message:", message);
// alert(message);

